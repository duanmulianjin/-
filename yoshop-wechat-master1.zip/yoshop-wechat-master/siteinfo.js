/**
 * 配置文件
 */
module.exports = {
  name: "萤火小程序商城",
  siteroot: "http://192.168.2.110/" // 必填: api地址，结尾要带/
};